// vue.config.js
module.exports = {
    runtimeCompiler: true,
    // rules: {
    //     'no-console': 'off',
    // },
};