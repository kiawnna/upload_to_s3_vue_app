<template>
    <div id="app">
        <router-view></router-view>
    </div>
</template>
<script>
    export default {
        name: 'authenticate'
    }
</script>

<style scoped>
    #app div:first-of-type {
        margin-top: 60px;
    }
</style>
