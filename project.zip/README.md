## Local Project setup
The app uses AWS Cognito for authentication and authorization. These env vars are needed to run the app in any environment:
- VUE_APP_IDENTITY_POOL_ID
- VUE_APP_REGION
- VUE_APP_USER_POOL_ID
- VUE_APP_WEB_CLIENT_ID


Then run:
```
npm install
npm run serve
```

## Deployment
Runs a static production build of Vue.js, served by Nginx. There's an optional CF template that takes a Cluster ARN and IAM Role ARN and creates a service and task definition.
